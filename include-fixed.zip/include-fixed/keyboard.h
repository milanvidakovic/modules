
void irq_triggered();
int is_key_pressed();

