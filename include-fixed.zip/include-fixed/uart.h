void init_uart();
void send_uart(unsigned char b);
void read_uart(unsigned char *buffer, int len);
