void pixel(int x, int y, int color);                    // 190400
void line(int x1, int y1, int x2, int y2, int color);   // 190404
void circle(int x, int y, int r, int color);            // 190408
void draw(int x, int y, int c, char *s);                // 190412
