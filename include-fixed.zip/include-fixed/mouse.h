short int mouse_status(short int *x, short int *y, short int *key);
void init_mouse(short int x, short int y);
void de_init_mouse();
