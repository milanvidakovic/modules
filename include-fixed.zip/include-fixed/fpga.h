void reset();

void scroll_up();

