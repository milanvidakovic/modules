#include <stdarg.h>
int sprintf(char *dst, char* fmt, ...);             // 190300
int vsprintf(char *dst,char* fmt, va_list args);    // 190304
